<?php
header('Content-type: application/msword');
header('Content-Disposition: attachment; filename=result.rtf');

// Шаблон документа
$file = 'templates/1.rtf';

if(isset($_POST["submit"]))
{
    // Считываем содержимое rtf-файла
    $doc_content = file_get_contents($file);

    // Имя временного файла (отчет)
    $report_filename = "reports/".time().".rtf";

    // Получаем значения полей из формы
    $NUMBER = $_POST["NUMBER"];
    $DATE = $_POST["DATE"];
    $REESTER_CODE = $_POST["REESTER_CODE"];
    $UPPER_CODE = $_POST["UPPER_CODE"];
    $FPOST = $_POST["FPOST"];
    $FPOST_FIO = $_POST["FPOST_FIO"];
    $SPOST = $_POST["SPOST"];
    $CPOST = $_POST["CPOST"];
    $CPOST_FIO = $_POST["CPOST_FIO"];
    $SPOST_FIO = $_POST["SPOST_FIO"];
    $BUKH = $_POST["BUKH"];
    $BUKH_FIO = $_POST["BUKH_FIO"];
    $INDEX = $_POST["INDEX"];
    $SUBJECT = $_POST["SUBJECT"];
    $LOCALITY = $_POST["LOCALITY"];
    $STREET = $_POST["STREET"];
    $HOUSE = $_POST["HOUSE"];
    $CORP = $_POST["CORP"];
    $TYPE_ROOM = $_POST["TYPE_ROOM"];;
    // Замена строк

    $new_doc_content = str_replace("NUMBER", $NUMBER, $doc_content);
    $new_doc_content = str_replace("DATE", $DATE, $new_doc_content);
    $new_doc_content = str_replace("REESTER_CODE", $REESTER_CODE, $new_doc_content);
    $new_doc_content = str_replace("UPPER_CODE", $UPPER_CODE, $new_doc_content);
    $new_doc_content = str_replace("SPOST", $SPOST, $new_doc_content);
    $new_doc_content = str_replace("FIRST", $FPOST_FIO, $new_doc_content);
    $new_doc_content = str_replace("FPOST", $FPOST, $new_doc_content);
    $new_doc_content = str_replace("SECOND", $SPOST_FIO, $new_doc_content);
    $new_doc_content = str_replace("CPOST", $CPOST, $new_doc_content);
    $new_doc_content = str_replace("CLIENT", $CPOST_FIO, $new_doc_content);
    $new_doc_content = str_replace("BUKH", $BUKH, $new_doc_content);
    $new_doc_content = str_replace("FIO", $BUKH_FIO, $new_doc_content);
    $new_doc_content = str_replace("INDEX", $INDEX, $new_doc_content);
    $new_doc_content = str_replace("SUBJECT", $SUBJECT, $new_doc_content);
    $new_doc_content = str_replace("LOCALITY", $LOCALITY, $new_doc_content);
    $new_doc_content = str_replace("STREET", $STREET, $new_doc_content);
    $new_doc_content = str_replace("HOUSE", $HOUSE, $new_doc_content);
    $new_doc_content = str_replace("CORP", $CORP, $new_doc_content);
    $new_doc_content = str_replace("TYPE_ROOM", $TYPE_ROOM, $new_doc_content);

    $new_doc_content = mb_convert_encoding($new_doc_content, "Windows-1251", "utf8");

    // Записываем обновленное содержимое отчета во временный файл
    $fp = fopen($report_filename, 'w');
    fwrite($fp, $new_doc_content);
    fclose($fp);

    // Скачиваем файл
    downloadFile($report_filename);
}
function downloadFile($stringFilePath){
    $file_to_download = $stringFilePath; // file to be downloaded
    header("Expires: 0");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");  header("Content-type: application/file");
    header('Content-length: '.filesize($file_to_download));
    header('Content-disposition: attachment; filename="'.basename($file_to_download).'"');
    readfile($file_to_download);
}
