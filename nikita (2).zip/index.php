<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Конструктор</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/script.js"></script>
</head>

<body>
  <main class="container col-12 col-sm-8 col-md-6">
    <h4 class="text-start">Конструктор формирования карточки образцов подписей</h4>
    <form method="post" action="generate.php" class="form">
      <div class="inputs-group">
        <label for="test-select" class="input-block__label">
          <p class="input-block__text"> Выберите тип организации</p>
          <select name="type" class="input-block__input form-control form-select" id="option">
            <option selected></option>
            <option value="1">КУ/РБС</option>
            <option value="2">АУ/БУ/ЮЛ</option>
            <option value="3">Обособленное подразделение – филиал АУ/БУ</option>
            <option value="4">ГРБС</option>
          </select>
        </label>
        <label for="test1" class="input-block__label">
          <p class="input-block__text"> Номер карточки образцовой подписей: </p>
          <input required name="NUMBER" required class="input-block__input form-control" type="text" id="test0">
        </label>
        <label for="test2" class="input-block__label">
          <p class="input-block__text">Дата составления документа:</p>
          <input required name="DATE" class="input-block__input form-control" type="date" id="test2">
        </label>
        <label for="test3" class="input-block__label">
          <p class="input-block__text">Код организации по Сводному реестру:</p>
          <input required name="REESTER_CODE" class="input-block__input form-control" type="text" maxlength="8" id="input-field">
        </label>
        <label for="test4" class="input-block__label">
          <p class="input-block__text">Код вышестоящей организации по Сводному реестру:</p>
          <input required name="UPPER_CODE" class="input-block__input form-control" type="text" maxlength="8" id="test4">
        </label>
      </div>
      <h1 style="font-size:18px">Адрес организации</h1>
      <div class="inputs-group">
        <label for="index" class="input-block__label">
          <p class="input-block__text"> Индекс: </p>
          <input required class="input-block__input form-control" type="tel" id="index" name="INDEX">
        </label>
        <label for="subject" class="input-block__label">
          <p class="input-block__text"> Субъект РФ: </p>
          <select required id="subject" name = "SUBJECT" class="input-block__input form-control form-select">
            <option selected></option>
            <option>Республика Адыгея</option>
            <option>Республика Алтай</option>
            <option>Республика Башкортостан</option>
            <option>Республика Бурятия</option>
            <option>Республика Дагестан</option>
            <option>Донецкая Народная Республика</option>
            <option>Республика Ингушетия</option>
            <option>Кабардино-Балкарская Республика</option>
            <option>Республика Карелия</option>
            <option>Республика Коми</option>
            <option>Республика Крым</option>
            <option>Луганская Народная Республика</option>
            <option>Республика Марий Эл</option>
            <option>Республика Мордовия</option>
            <option>Республика Саха(Якутия)</option>
            <option>Республика Северная Осетия-Алания</option>
            <option>Республика Татарстан(Татарстан)</option>
            <option>Республика Тыва</option>
            <option>Удмуртская Республика</option>
            <option>Республика Хакасия</option>
            <option>Чеченская Республика</option>
            <option>Чувашская Республика-Чувашия</option>
            <option>Алтайский Край</option>
            <option>Забайкальский Край</option>
            <option>Камчатский Край</option>
            <option>Краснодарский Край</option>
            <option>Красноярский Край</option>
            <option>Пермский Край</option>
            <option>Приморский Край</option>
            <option>Ставропольский Край</option>
            <option>Хабаровский Край</option>
            <option>Амурская область</option>
            <option>Архангельская область</option>
            <option>Астраханская область</option>
            <option>Белгородская область</option>
            <option>Брянская область</option>
            <option>Владимирская область</option>
            <option>Волгоградская область</option>
            <option>Вологодская область</option>
            <option>Воронежская область</option>
            <option>Запорожская область</option>
            <option>Ивановская область</option>
            <option>Иркутская область</option>
            <option>Калининградская область</option>
            <option>Калужская область</option>
            <option>Кемеровская область</option>
            <option>Кировская область</option>
            <option>Костромская область</option>
            <option>Курганская область</option>
            <option>Курская область</option>
            <option>Ленинградская область</option>
            <option>Липецкая область</option>
            <option>Магаданская область</option>
            <option>Московская область</option>
            <option>Мурманская область</option>
            <option>Нижегородская область</option>
            <option>Новгородская область</option>
            <option>Новосибирская область</option>
            <option>Омская область</option>
            <option>Оренбургская область</option>
            <option>Орловская область</option>
            <option>Пензенская область</option>
            <option>Псковская область</option>
            <option>Ростовская область</option>
            <option>Рязанская область</option>
            <option>Самарская область</option>
            <option>Саратовская область</option>
            <option>Сахалинская область</option>
            <option>Свердловская область</option>
            <option>Смоленская область</option>
            <option>Тамбовская область</option>
            <option>Тверская область</option>
            <option>Томская область</option>
            <option>Тульская область</option>
            <option>Тюменская область</option>
            <option>Ульяновская область</option>
            <option>Херсонская область</option>
            <option>Челябинская область</option>
            <option>Ярославская область</option>
            <option>Москва</option>
            <option>Санкт-Петербург</option>
            <option>Севастополь</option>
            <option>Еврейская автономная область</option>
            <option>Ненецкий автономный округ</option>
            <option>Ханты-Мансийский автономный округ - Югра</option>
            <option>Чукотский автономный округ</option>
            <option">Ямало-Ненецкий автономный округ</option>



          </select>
        </label>
        <label for="place" class="input-block__label">
          <p class="input-block__text">Населенный пункт:</p>
          <input required class="input-block__input form-control" placeholder="город Владикавказ, село Гизель..." type="text"
            id="place" name="LOCALITY">
        </label>
        <label for="street" class="input-block__label">
          <p class="input-block__text">Улица:</p>
          <input required class="input-block__input form-control" placeholder="проспект Мира, улица Ленина..." type="text"
            id="street" name="STREET">
        </label>
        <div class="twice-row">
          <label for="house" class="input-block__label">
            <p class="input-block__text">Дом:</p>
            <input class="input-block__input form-control" type="tel" id="house" name="HOUSE">
          </label>
          <label for="block" class="input-block__label">
            <p class="input-block__text">Корпус:</p>
            <input class="input-block__input form-control" type="tel" id="block" name="CORP">
          </label>
        </div>
        <label for="type" class="special-row">
          <p class="input-block__text">Помещение:</p>
          <select id="type" class="input-block__input form-control form-select">
            <option selected></option>
            <option value="1">Кабинет</option>
            <option value="2">Офис</option>
            <option value="3">Помещение</option>
            <option value="4">Комната</option>
            <option value="5">Иное</option>
          </select>
          <input class="input-block__input form-control" type="text" id="type-number" name="TYPE_ROOM">
      </div>
      <div class="inputs-group my-5">
        <h5>Сотрудник наделённый правом первой подписи</h5>
        <div id="firstSignContainer">
          <div id="firstSign">
            <label for="post" class="input-block__label">
              <p class="input-block__text">Должность</p>
              <input required class="input-block__input form-control" type="text" id="post" name="FPOST">
            </label>
            <label for="name" class="input-block__label">
              <p class="input-block__text">ФИО</p>
              <input  required class="input-block__input form-control" type="text" id="name" name="FPOST_FIO">
            </label>
          </div>
        </div>
      </div>
      <input type="button" id="firstClone" class="btn btn-primary" value="Добавить">
      <div class="inputs-group my-5">
        <h5>Сотрудник наделённый правом второй подписи</h5>
        <div id="secondSignContainer">
          <div id="secondSign">
            <label for="post" class="input-block__label">
              <p class="input-block__text">Должность</p>
              <input required class="input-block__input form-control" type="text" id="post" name="SPOST">
            </label>
            <label for="name" class="input-block__label">
              <p class="input-block__text">ФИО -</p>
              <input required class="input-block__input form-control" type="text" id="name" name="SPOST_FIO">
            </label>
          </div>
        </div>
      </div>
      <input type="button" id="secondClone" class="btn btn-primary" value="Добавить">

      <div class="inputs-group my-5">
        <h5>Документ утверждается</h5>
        <p><b>Руководитель клиента (уполномоченное лицо)</b></p>
        <label for="post" class="input-block__label">
          <p class="input-block__text">Должность</p>
          <input required class="input-block__input form-control" type="text" id="post" name="CPOST">
        </label>
        <label for="name" class="input-block__label">
          <p class="input-block__text">ФИО</p>
          <input required class="input-block__input form-control" type="text" id="name" name="CPOST_FIO">
        </label>
        <p><b>Главный бухгалтер клиента(уполномоченное лицо)</b></p>
        <label for="post" class="input-block__label">
          <p class="input-block__text">Должность</p>
          <input required name="BUKH" class="input-block__input form-control" type="text" id="post">
        </label>
        <label for="name" class="input-block__label">
          <p class="input-block__text">ФИО</p>
          <input required name="BUKH_FIO" class="input-block__input form-control" type="text" id="name">
        </label>
      </div>
      </div>
      <button type="submit" name="submit" class="btn btn-primary">Сохранить</button>
    </form>
    </div>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
    crossorigin="anonymous"></script>

</body>

</html>